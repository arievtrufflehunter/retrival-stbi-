# information-retrival-revisi
1501650002
